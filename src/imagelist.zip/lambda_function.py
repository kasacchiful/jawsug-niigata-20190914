from PIL import Image
import boto3
import urllib.parse
import os
import json
from datetime import datetime  # add

DST_BUCKET = os.environ['DST_BUCKET']
MAX_WIDTH  = os.environ.get('MAX_WIDTH', 100)
MAX_HEIGHT = os.environ.get('MAX_HEIGHT', 100)
DYNAMODB_TABLE = os.environ.get('DYNAMODB_TABLE', 'jawsug-niigata-20190914-imagelist')  # add

def lambda_handler(event, context):
    src_bucket = event['Records'][0]['s3']['bucket']['name']
    src_key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')

    dst_bucket = DST_BUCKET
    splitext = os.path.splitext(src_key)
    dst_key = '{}_thumb{}'.format(splitext[0], splitext[1])

    tmp = '/tmp/' + os.path.basename(src_key)

    s3 = boto3.client('s3')
    dynamodb = boto3.client('dynamodb')  # add
    try:
        s3.download_file(Bucket=src_bucket, Key=src_key, Filename=tmp)
        img = Image.open(tmp)
        img.thumbnail((MAX_WIDTH, MAX_HEIGHT), Image.LANCZOS)
        img.save(tmp)
        s3.upload_file(Filename=tmp, Bucket=dst_bucket, Key=dst_key, ExtraArgs={'ACL': 'public-read'})  # add public-read ACL
        ## add start
        nowtime = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        dynamodb.put_item(
            TableName = DYNAMODB_TABLE,
            Item = {
                'id': {'S': 'ImageList'},
                'timestamp': {'S': nowtime},
                'original': {'S': src_key},
                'thumbnail': {'S': dst_key},
            }
        )
        ## add end
        ret = {
            'statusCode': 200,
            'body': json.dumps({'message': 'create thumbnail: {0}/{1}'.format(dst_bucket, dst_key)})
        }
        return ret
    except Exception as e:
        print(e)
        raise e
